package com.example.recordatorios

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
