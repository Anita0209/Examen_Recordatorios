import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'crear_recordatorio.dart';
class Recordatorios extends StatefulWidget {
  const PantallaRecordatorios({Key? key}) : super(key: key);

  @override
  _RecordatoriosState createState() => _RecordatoriosState();
}

class _RecordatoriosState extends State<Recordatorios> {
  final _formKey = GlobalKey<FormState>();
  final _tituloController = TextEditingController();
  final _contenidoController = TextEditingController();



    // Vuelve a la pantalla anterior y actualiza los datos
    Navigator.pop(context, true);
  }

  Widget _crearFormulario() {
    return Padding(
      padding: EdgeInsets.all(16),
      child: Form(
        key: _formKey,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: <Widget>[
            TextFormField(
              decoration: InputDecoration(
                labelText: 'Título',
                border: OutlineInputBorder(),
              ),
              maxLength: 255,
              validator: (value) {
                if (value == null || value.isEmpty) {
                  return 'Por favor, ingresa un título';
                }
                return null;
              },
            ),
            SizedBox(height: 16),
            TextFormField(
              decoration: InputDecoration(
                labelText: 'Contenido',
              ),
              maxLines: null,
              validator: (value) {
                if (value == null || value.isEmpty) {
                  return 'Por favor, ingresa un contenido';
                }
                return null;
              },
            ),
            SizedBox(height: 16),
            ElevatedButton(
              child: Text('Guardar'),
              onPressed: () {
                guardarRecordatorio();
              }),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Crear Recordatorio'),
      ),
      body: _crearFormulario(),
    );
  }

