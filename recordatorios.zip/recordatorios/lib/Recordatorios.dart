import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class Recordatorios extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Crear Recordatorio'),
      ),
    body: StreamBuilder<QuerySnapshot>(
    stream: FirebaseFirestore.instance.collection('recordatorios').snapshots(),
    builder: (context, snapshot) {
    if (!snapshot.hasData) {
    return Center(
    child: CircularProgressIndicator(),
    );
    }

    final recordatorios = snapshot.data!.docs;

    return ListView.builder(
    itemCount: recordatorios.length,
    itemBuilder: (context, index) {
    final recordatorio = recordatorios[index].data() as Map<String, dynamic>;

    return ListTile(
    title: Text(recordatorio['titulo']),
    subtitle: Text(recordatorio['descripcion']),
    trailing: Text(recordatorio['fecha'].toString()),
    );
    },
    );
    },
    ),
    );
  }}
