import 'package:cloud_firestore/cloud_firestore.dart';


// ...

// Define la estructura de datos para la nota
class Note {
  String title;
  String content;
  Timestamp createdDate;
  Timestamp updatedDate;

  Note({
    required this.title,
    required this.content,
    required this.createdDate,
    required this.updatedDate,
  });
}



// Crea una nueva nota en Firebase
void createNote(String title, String content) async {
  // Crea una nueva instancia de Firestore
  FirebaseFirestore firestore = FirebaseFirestore.instance;

  // Crea una nueva nota con los datos proporcionados por el usuario
  Note newNote = Note(
    title: title,
    content: content,
    createdDate: Timestamp.now(),
    updatedDate: Timestamp.now(),
  );

  // Agrega la nota a la colección "notes" en Firestore
  await firestore.collection('notas').add({
    'titulo': newNote.title,
    'contenido': newNote.content,
    'createdDate': newNote.createdDate,
    'updatedDate': newNote.updatedDate,
  });
}

