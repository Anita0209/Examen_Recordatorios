import 'package:flutter/material.dart';
import 'notas.dart';
import 'recordatorios.dart';
import 'crear_recordatorio.dart';
import 'crear_nota.dart';
import 'crear_recordatorio.dart';
import 'package:firebase_core/firebase_core.dart';
// Importamos la configuarcion creada por FlutterFire
import 'firebase_options.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(
    options: DefaultFirebaseOptions.currentPlatform,
  );
  runApp(MyApp());
}


class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Mi aplicación de Notas y Recordatorios',
      home: DefaultTabController(
        length: 2,
        child: Scaffold(
          appBar: AppBar(
            title: Text('Notas y Recordatorios'),
            bottom: TabBar(
              tabs: [
                Tab(text: 'Notas'),
                Tab(text: 'Recordatorios'),
              ],
            ),
          ),
          body: TabBarView(
            children: [
              PantallaNotas(),
              PantallaRecordatorio(),
            ],
          ),
        ),
      ),
    );
  }
}

class PantallaNotas extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: <Widget>[
          ElevatedButton(
            child: Text('Crear Nota'),
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => CrearNota()),
              );
            },
          ),
        ],
      ),
    );
  }
}

class PantallaRecordatorio extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: <Widget>[
          ElevatedButton(
            child: Text('Crear recordatorio'),
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => Recordatorios),
              );
            },
          ),
        ],
      ),
    );
  }
}





