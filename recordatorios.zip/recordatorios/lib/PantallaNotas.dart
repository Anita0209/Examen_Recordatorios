import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:recordatorios/notas.dart';
import 'crear_nota.dart';

class PantallaNotas extends StatefulWidget {
  const PantallaNotas({Key? key}) : super(key: key);

  @override
  _PantallaNotasState createState() => _PantallaNotasState();
}

class _PantallaNotasState extends State<PantallaNotas> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Notas'),
      ),
      body: Column(
        children: <Widget>[
          Expanded(
            child: StreamBuilder<QuerySnapshot>(
              stream: FirebaseFirestore.instance.collection('notas').snapshots(),
              builder: (BuildContext context, AsyncSnapshot<QuerySnapshot> snapshot) {
                if (!snapshot.hasData) {
                  return Center(child: CircularProgressIndicator());
                }
                final notas = snapshot.data!.docs;
                if (notas.isEmpty) {
                  return Center(
                    child: Text('No hay notas'),
                  );
                }
                return ListView.builder(
                  itemCount: notas.length,
                  itemBuilder: (context, index) {
                    return ListTile(
                      title: Text(notas[index]['titulo']),
                      subtitle: Text(notas[index]['contenido']),
                      onTap: () async {
                        final result = await Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (context) => CrearNota(nota: notas[index]),
                          ),
                        );
                        if (result == 'guardado') {
                          setState(() {}); // Actualizar la lista de notas
                        }
                      },
                    );
                  },
                );
              },
            ),
          ),
          SizedBox(
            height: 10,
          ),
          ElevatedButton(
            child: Text('Crear Nota'),
            onPressed: () async {
              final result = await Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => CrearNota(),
                ),
              );
              if (result == 'guardado') {
                setState(() {}); // Actualizar la lista de notas
              }
            },
          ),
          SizedBox(
            height: 10,
          ),
        ],
      ),
    );
  }
}
