import 'package:cloud_firestore/cloud_firestore.dart';

class Reminder {
  String title;
  String content;
  String note;
  DateTime createdAt;
  DateTime updatedAt;

  Reminder({
    required this.title,
    required this.content,
    this.note = '',
    required this.createdAt,
    required this.updatedAt,
  });

  factory Reminder.fromFirestore(DocumentSnapshot doc) {
    Map data = doc.data() as Map<String, dynamic>;
    return Reminder(
      title: data['title'],
      content: data['content'],
      note: data['note'] ?? '',
      createdAt: (data['created_at'] as Timestamp).toDate(),
      updatedAt: (data['updated_at'] as Timestamp).toDate(),
    );
  }

  Map<String, dynamic> toFirestore() {
    return {
      'title': title,
      'content': content,
      'note': note,
      'created_at': Timestamp.fromDate(createdAt),
      'updated_at': Timestamp.fromDate(updatedAt),
    };
  }
}

void guardarRecordatorio() async {
  FirebaseFirestore firestore = FirebaseFirestore.instance;

  Reminder nuevoRecordatorio = Reminder(
    title: 'Título del recordatorio',
    content: 'Contenido del recordatorio',
    note: 'Nota opcional',
    createdAt: DateTime.now(),
    updatedAt: DateTime.now(),
  );

  await firestore.collection('recordatorios').add(nuevoRecordatorio.toFirestore());
}
