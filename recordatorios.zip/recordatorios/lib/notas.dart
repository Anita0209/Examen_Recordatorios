import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
// Importamos la configuarcion creada por FlutterFire
import 'firebase_options.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'crear_nota.dart';

class CrearNota extends StatefulWidget {
  final DocumentSnapshot? nota;

  const CrearNota({Key? key, this.nota}) : super(key: key);

  @override
  _CrearNotaState createState() => _CrearNotaState();
}

class _CrearNotaState extends State<CrearNota> {
  // Definir variables para el título y el contenido de la nota
  String _titulo = '';
  String _contenido = '';

  // Función para guardar la nota en Firebase
  void _guardarNota() async {
    // Obtener el usuario actualmente autenticado


    // Crear un nuevo documento con un ID generado automáticamente


    var notasRef;
    DocumentReference nuevaNotaRef = notasRef.doc();

    // Obtener la fecha actual
    DateTime fechaActual = DateTime.now();

    // Crear un mapa con los datos de la nota
    Map<String, dynamic> nota = {
      'titulo': _titulo,
      'contenido': _contenido,
      'fechaCreacion': fechaActual,
      'fechaActualizacion': fechaActual,
    };

    // Guardar la nota en Firebase
    await nuevaNotaRef.set(nota);

    // Regresar a la pantalla anterior y enviar la nota creada
    Navigator.of(context).pop(nota);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Crear nota'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Campo para el título de la nota
            TextField(
              decoration: InputDecoration(
                hintText: 'Título',
              ),
              onChanged: (value) {
                setState(() {
                  _titulo = value;
                });
              },
            ),
            SizedBox(height: 16.0),
            // Campo para el contenido de la nota
            TextField(
              decoration: InputDecoration(
                hintText: 'Contenido',
              ),
              maxLines: null,
              onChanged: (value) {
                setState(() {
                  _contenido = value;
                });
              },
            ),
            SizedBox(height: 16.0),
            // Botón para guardar la nota
            ElevatedButton(
              onPressed: () {
                createNote(_titulo, _contenido);
                Navigator.pop(context); // Navegar de regreso a la pantalla de Notas
              },
              child: Text('Guardar'),
            ),

          ],
        ),
      ),
    );
  }
}
